<!DOCTYPE html>

<head>

	<title>Ubiko</title>
	
	<link rel="shortcut icon" href="ubiko.ico" >
	<link href="css/css1.css" rel="stylesheet" type="text/css"  />
	
</head>

<body >
	<div align="center">
	<header id=cab>
		<div id=cont_logo>
		<div id=logo>
			<div><a href="home.php" class="linkcontent"><img alt="logotipo" src="./img/logo.jpg"/></a></div>
		</div>
		</div>
	
		<div id=login>
			<div id=img_log>
				<div><img alt="login" src="./img/login.jpg"/></div>
				<div id=bot_log>
				<div><a href="login.php" class="linkcontent"><img alt="botón login" src="./img/bot_log.jpg"/></a></div>
				</div>
				<div id="pass"><input type="password" size="18" /></div>
			</div>
		</div>
		
		<!--menu-->
		<nav id=navegacion>
				<ul>
					<li><a href="admision.php" class="enlace_admision_h linkcontent">Admisi&oacute;n</a></li>       
					<li><a href="seguimiento.php" class="seguimiento_h  linkcontent">Seguimiento</a></li>       
					<li><a href="box.php" class="box_h  linkcontent">BOX</a></li>      
					<li><a href="estadisticas.php" class="estadistcicas_h  linkcontent">Estad&iacute;sticas</a></li>     
				</ul>
		</nav>
	
	
	
	</header>
	
	<div id=contenedor>
	</div>
	</div>
</body>
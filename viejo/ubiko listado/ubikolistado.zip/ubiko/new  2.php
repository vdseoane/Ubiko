<!DOCTYPE html>

<html>
<head>

	<title>Ubiko</title>
	
	<link rel="shortcut icon" href="ubiko.ico" >
	<link href="css/css1.css" rel="stylesheet" type="text/css"  />
	
</head>

<body>
	
	<header id=cab>
		<div id=cont_logo>
		<div id=logo>
			<div><a href="home.php" class="linkcontent"><img alt="logotipo" src="./img/logo.jpg"/></a></div>
		</div>
		</div>
	
		<div id=login>
			<div id=img_log>
				<div><img alt="login" src="./img/login.jpg"/></div>
				<div id=bot_log>
				<div><a href="login.php" class="linkcontent"><img alt="botón login" src="./img/bot_log.jpg"/></a></div>
				</div>
				<div id="pass"><input type="password" size="18" /></div>
			</div>
		</div>
		
		<!--menu-->
		<nav id=navegacion>
				<ul>
					<li><a href="admision.php" class="enlace_admision_h linkcontent">Admisi&oacute;n</a></li>       
					<li><a href="seguimiento.php" class="seguimiento_h  linkcontent">Seguimiento</a></li>       
					<li><a href="box.php" class="box_h  linkcontent">BOX</a></li>      
					<li><a href="estadisticas.php" class="estadistcicas_h  linkcontent">Estad&iacute;sticas</a></li>     
				</ul>
		</nav>
	
	
	
	</header>
	
	<div id=contenedor>
		<div id=cambio>
			    <div class="buscar_paciente centro">
					<div class="izquierda">
						<div class="izquierda" id="numero">n&deg;</div>
						<div class="izquierda" id="paciente">paciente</div>
						<div class="izquierda"><input id="busqueda" type="text"/></div>
						<div class="izquierda" id=buscar><a href="" class="linkcontent"><img alt="buscar" src="./img/buscar.jpg"/></a></div>
						<div class="izquierda" id="nhc">NHC</div>
				     </div>
			  	  
				
		
		
				</div>
			
			     <div id=cambio2>
			         <div  class="izquierda1" id=cambio3>
					     <div  id=control_paciente>
						     
						          <div class="izquierda2">
								  <a href="" class="linkcontent">
								  <div class="izquierda5">
						                     <div class="izquierda5" id="num">22</div>
						                     <div class="izquierda5" id="nombre">Maria del Pilar Garcia del Monte</div>
											 <div class="izquierda5" id="num1">1286</div>
								      </div>
									  </a>
								  </div>
			   
			                 
			             </div>
			        </div>
				     <div class="izquierda1" id=cambio4>
                          <div  id=control_paciente>
						   <div class="izquierda3">
								  <a href="" class="linkcontent">
								  <div class="izquierda4">
						                     <div class="izquierda4" id="num">22</div>
						                     <div class="izquierda4" id="nombre">Maria del Pilar Garcia del Monte</div>
											 <div class="izquierda4" id="num1">1286</div>
								      </div>
									  </a>
								  </div>
			             </div>			   
			        
			   
			         </div>	
					
				 </div>	
			</div>
	   </div>
	   
	</div>
	
	
	
   	

	
	
</body>
</html>

